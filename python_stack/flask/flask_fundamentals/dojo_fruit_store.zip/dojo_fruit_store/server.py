from flask import Flask, render_template, request, redirect
app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    print(request.form)
    rq = request.form
    apple = rq['apple']
    raspberry = rq['raspberry']
    strawberry = rq['strawberry']
    first_name = rq['first_name']
    last_name = rq['last_name']
    student_id = rq['student_id']
    print(f"Charging {first_name} {last_name} for {apple+strawberry+raspberry} fruits")
    return render_template("checkout.html", 
                            apple=apple, 
                            raspberry=raspberry, 
                            strawberry=strawberry, 
                            first_name=first_name, 
                            last_name=last_name, 
                            student_id=student_id)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    